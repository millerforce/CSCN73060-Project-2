var searchData=
[
  ['main_0',['main',['../_client_2main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;main.cpp'],['../_server_2main_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;main.cpp']]],
  ['main_2ecpp_1',['main.cpp',['../_client_2main_8cpp.html',1,'(Global Namespace)'],['../_server_2main_8cpp.html',1,'(Global Namespace)']]]
];
